# My-personal-website
CV website for self-presentation and headhunters

This project is aimed to present my person to the Internet :) and test some design and styling features I liked during observing different websites.
